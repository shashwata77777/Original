	<style type="text/css">
		
	</style>
	  <!-- Start Bradcaump area -->
        <div class="ht__bradcaump__area">
            <div class="ht__bradcaump__container">
            	<img src="<?php echo base_url();?>assets/images/bg-png/6.png" alt="bradcaump images">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="bradcaump__inner text-center">
                                <h2 class="bradcaump-title">Fee Policy</h2>
                                <nav class="bradcaump-inner">
                                  <a class="breadcrumb-item" href="<?php echo base_url();?>home">Home</a>
                                  <span class="brd-separetor"><img src="<?php echo base_url();?>/assets/images/icons/brad.png" alt="separator images"></span>
                                  <span class="breadcrumb-item active">Fee Policy</span>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Bradcaump area -->

	<!-- Start Welcame Area -->
		<section class="junior__welcome__area welcome--2 bg-image--9 section-padding--lg">
			<div class="container">
				<div class="row">
					<div class="col-lg-12 col-sm-12 col-md-12">
						<div class="section__title text-center">
							<h2 class="title__line">School <span class="title-color1">Fee</span> <span class="title-color2">Policy </span></h2>
							
						</div>
					</div>
				</div>
				
<style type="text/css">


.custom-counter {
  margin: 0;
  padding-left: 20px;
  list-style-type: none;

}

.custom-counter li {
  counter-increment: step-counter;
  margin-bottom: 10px;
  padding-left: 20px;
  position: relative;
}

.custom-counter li::before {

  content: counter(step-counter);
  margin-right: 5px;
  font-size: 80%;
  background-color: rgb(0,200,200);
  color: white;
  font-weight: bold;
  padding: 3px 8px;
  border-radius: 3px;


}

</style>					
					<div class="col-md-12 col-lg-12 col-sm-12 md-mt-40 sm-mt-40">
					
<div class="welcome__juniro__inner">
                <ol class="custom-counter">
            <li>The school fees & bus fees cover twelve calendar months and must be paid in advance.One time payment will have certain rebate. Bank will credit the fees &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;monthly on instruction.</li>
            <li>The fees are to be paid before 10th of each month failing which a late fee of Rs.50/- will be levied per month.</li>
            <li>Pupils have to pay fees until they are withdrawn with a request for Transfer Certificate.   Fees once paid are not refundable. </li>
            <li>All dues must be cleared before each term examination. Those who do not clear the dues will not be permitted to sit for any of the examinations.</li>
            <li>Since the final examinations start in the last week of February, students are supposed to clear the annual fees in February itself.  Otherwise they have to pay &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;the fine.</li>
            <li>The management reserves the right to increase the fees at any time of the year if an increment is deemed necessary. </li>
          </ol>
					 
					 </div>
				
			</div>
		</section>
		<!-- End Welcame Area -->