	<style type="text/css">
		<style type="text/css">
 li span { position: relative; left: -10px; }
</style>
	</style>
	  <!-- Start Bradcaump area -->
        <div class="ht__bradcaump__area">
            <div class="ht__bradcaump__container">
            	<img src="<?php echo base_url();?>assets/images/bg-png/6.png" alt="bradcaump images">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="bradcaump__inner text-center">
                                <h2 class="bradcaump-title">Infrastructure</h2>
                                <nav class="bradcaump-inner">
                                  <a class="breadcrumb-item" href="<?php echo base_url();?>home">Home</a>
                                  <span class="brd-separetor"><img src="<?php echo base_url();?>/assets/images/icons/brad.png" alt="separator images"></span>
                                  <span class="breadcrumb-item active">Infrastructure</span>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Bradcaump area -->

	<!-- Start Welcame Area -->
		<section class="junior__welcome__area welcome--2 bg-image--9 section-padding--lg">
			<div class="container">
				<div class="row">
					<div class="col-lg-12 col-sm-12 col-md-12">
						<div class="section__title text-center">
							<h2 class="title__line">School <span class="title-color1">Library</span> <span class="title-color2"></span></h2>
							
						</div>
					</div>
				</div>
				
				
					<div class="col-md-12 col-lg-12 col-sm-12 md-mt-40 sm-mt-40">
					
<div class="welcome__juniro__inner">
                <ol class="custom-counter">
            <li>Students can borrow only one book at a time and may retain it only for a period of one week. Books borrowed are not transferable. </li>
            <li>If a book is not returned on the due date a fine of Re.1 per day thereafter is imposed. </li>
            <li>Reference books, periodicals, etc. should not be taken out of the reading room. </li>
            <li>Borrowers should report any damage, loss of pages, pictures etc. to the   Librarian before they accept the book. If any book is lost, damaged or badly handled, &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;the actual cost for the replacement of the book will have to be paid by the borrower. No page shall be mutilated, torn or spoilt.  </li>
            <li>Strict silence should be maintained inside the Library and Reading Room.</li>
            <li>Students shall not enter any other classrooms at any time. They are supposed to look after their own articles. They shall not bring to school valuable and &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;curious articles, gold ornaments or electronic gadgets. Possession and use of mobile phone is strictly prohibited on the school campus and in school buses.</li>
            <li>The classrooms, corridors and the school premises shall be kept neat and clean. Waste papers or other waste materials must be thrown into the dust bins &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;provided. Students should take care that the display boards, walls, furniture, black boards, shelves, etc. are kept neat and in order.</li>
            
          </ol>
					 
					 </div>
				
			</div>
		</section>
		<!-- End Welcame Area -->