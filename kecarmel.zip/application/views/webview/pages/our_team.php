	<style type="text/css">
		
	</style>
	  <!-- Start Bradcaump area -->
        <div class="ht__bradcaump__area">
            <div class="ht__bradcaump__container">
            	<img src="<?php echo base_url();?>assets/images/bg-png/banner2.png" alt="bradcaump images">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="bradcaump__inner text-center">
                                <h2 class="bradcaump-title">Our Team</h2>
                                <nav class="bradcaump-inner">
                                  <a class="breadcrumb-item" href="<?php echo base_url();?>home">Home</a>
                                  <span class="brd-separetor"><img src="<?php echo base_url();?>/assets/images/icons/brad.png" alt="separator images"></span>
                                  <span class="breadcrumb-item active">Our Team</span>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Bradcaump area -->

	<!-- Start Welcame Area -->
		<section class="junior__welcome__area welcome--2 bg-image--9 section-padding--lg">
			<div class="container">
				<div class="row">
					<div class="col-lg-12 col-sm-12 col-md-12">
						<div class="section__title text-center">
						<h2 class="title__line"><span class="title-color1">K.E.</span> <span class="title-color2">Carmel</span> School  Amtala  Staff   2018-19</h2>
							
						</div>
					</div>
				</div>
				

			
					<div class="col-md-12 col-lg-12 col-sm-12 md-mt-40 sm-mt-40">
						<div class="welcome__juniro__inner">


              <div class="container">
                    
                <table class="table table-striped table-hover" style="color:#458aaa;">
                  <thead>
                    <tr style="color: #ae76b1;">
                      <th width="10%" >Srl. No.</th>
                      <th width="60%" >Name</th>
                      <th width="30%" >Qualification</th>
                    </tr>
                  </thead>
                  <tbody>
                  <tr> <td>1</td><td>Dr. Fr.Paul Mathew Thamarachary CMI   (Secretary)    </td> <td>M.A., B.Ed. , Phd</td></tr>
                  <tr> <td>2</td><td>Fr. Jojo Thuruthayil CMI   (Principal)          </td> <td>M.A., B.Ed., MBA</td></tr>
                  <tr> <td>3</td><td> Fr. George  Panamthottam CMI </td><td>M.A., B.Ed.</td></tr>
                  <tr> <td>4</td><td>Ananya Chatterjee</td><td>B.A.</td></tr>
                  <tr> <td>5</td><td>Ananya Das</td><td>M.Sc.</td></tr>
                  <tr> <td>6</td><td>Anuradha Panday</td><td> MP</td></tr>
                  <tr> <td>7</td><td>Arpita Dey</td><td>B.Tech</td></tr>
                  <tr> <td>8</td><td>Arpita Ghosh</td><td>M.Sc.</td></tr>
                  <tr> <td>9</td><td>Ayan Basu </td><td>M.A,B.Ed</td></tr>
                  <tr> <td>10</td><td>Debasree Datta</td><td> M.Com.,PGDFA,B.Ed.</td></tr>
                  <tr> <td>11</td><td>Dipesh Kumar Barua</td><td> B.Com, T.T.C </td></tr>
                  <tr> <td>12</td><td>Disha Mahapatra  </td><td>B.Sc. , B.Ed</td></tr>
                  <tr> <td>13</td><td>Enid Sebastian</td><td>B.A., T.T.C  </td></tr>
                  <tr> <td>14</td><td>Eti  Halder</td><td>M.A., B.Music,  Sangeet Bisharad</td></tr>
                  <tr> <td>15</td><td> Gargee Chatterjee  </td><td>B.Sc.</td></tr>
                  <tr> <td>16</td><td>Gargee  Dey </td><td>M.A.</td></tr>
                  <tr> <td>17</td><td>Gopa Chakraborty </td><td>B.A.,  Sr T.T.C.</td></tr>
                  <tr> <td>18</td><td>Indu Thapa </td><td> M.A. , B.Ed.</td></tr>
                  <tr> <td>19</td><td>Jasmine Kaur</td><td>B.Com(H), STTT</td></tr>
                  <tr> <td>20</td><td>J.N. Dutta</td><td>M.Sc., B.Ed. </td></tr>
                  <tr> <td>21</td><td>Kamal Mitra </td><td>B.Sc., B.Ed.</td></tr>
                  <tr> <td>22</td><td>Kamelia Ali </td><td> M.Sc., M.A., GNIIT-B.Ed  </td></tr>
                  <tr> <td>23</td><td>Kaushik Dey  </td><td>B.Com(H)</td></tr>
                  <tr> <td>24</td><td>Ketaki Dey </td><td>M.Sc., B.Ed.</td></tr>
                  <tr> <td>25</td><td>Latha Nair</td><td> M.A., B.Sc B.Ed.</td></tr>
                  <tr> <td>26</td><td>Madhusree Roy</td><td>M.A., B.Ed., PGBDC </td></tr>
                  <tr> <td>27</td><td>Manoj Kumar Gupta  </td><td>M.A., B.Ed.</td></tr>
                  <tr> <td>28</td><td>Mithu Ghosh </td><td>B.A., T.T.C </td></tr>
                  <tr> <td>29</td><td>Monami Roy</td><td>M.Sc., B.Ed.</td></tr>
                  <tr> <td>30</td><td>Mousumi Mondal</td><td>B.A., B. Ed.</td></tr>
                  <tr> <td>31</td><td>Mousumi Naskar</td><td>M.A. (Bengali), B.Ed.</td></tr>
                  <tr> <td>32</td><td>Mousumi Sangma </td><td>B.Sc., T.T.C</td></tr>
                  <tr> <td>33</td><td>Nabarun Bhattacharya</td><td>M.Sc.</td></tr>
                  <tr> <td>34</td><td>Paramita Bose </td><td>M.A. , B.Ed. </td></tr>
                  <tr> <td>35</td><td>Pinaki Halder </td><td>M.A., B.Ed. </td></tr>
                  <tr> <td>36</td><td>Pooja Bardhan  </td><td>MCA </td></tr>
                  <tr> <td>37</td><td>Pradip Patra</td><td>B.A., BP Ed</td></tr>
                  <tr> <td>38</td><td>Prasenjit Mondal</td><td>M.Sc., B.Ed. </td></tr>
                  <tr> <td>39</td><td>Puja Bhattacharya </td><td>M.A </td></tr>
                  <tr> <td>40</td><td>Radhamma G  </td><td>M.A., B.Ed</td></tr>
                  <tr> <td>41</td><td>Rekha Sinha  </td><td>M.A. B.Ed.</td></tr>
                  <tr> <td>42</td><td>Rima Chakraborty</td><td>M.A., B.Ed.,DELT</td></tr>
                  <tr> <td>43</td><td>Rituparna Bose </td><td>M.A.</td></tr>
                  <tr> <td>44</td><td>R.R Angelina Bose </td><td>B.A., Mont.</td></tr>
                  <tr> <td>45</td><td>Rupa Bagchi </td><td>M.Sc. </td></tr>
                  <tr> <td>46</td><td>Saheli Kar(Mukherjee) </td><td> M.A., B.Ed.</td></tr>
                  <tr> <td>47</td><td>Sambhunath Adhikary  </td><td>D V A</td></tr>
                  <tr> <td>48</td><td>Sampurna Sengupta </td><td>B.Tech</td></tr>
                  <tr> <td>49</td><td>Sapna Basu  </td><td>M.A.(Eco),M.Com, B.Ed </td></tr>
                  <tr> <td>50</td><td>Sayanta Karmakar </td><td> M.Sc.</td></tr>
                  <tr> <td>51</td><td>Sayanti Das </td><td> M.Sc. , M.A.</td></tr>
                  <tr> <td>52</td><td>Senjuti Chakraborty </td><td>B.A.(H) </td></tr>
                  <tr> <td>53</td><td>Soma Roy</td><td> M.Sc, B.Ed.</td></tr>
                  <tr> <td>54</td><td>Suchanda Rudra </td><td>B.A. </td></tr>
                  <tr> <td>55</td><td>Sudesna Chakraboty</td><td>M.Com. , STT </td></tr>
                  <tr> <td>56</td><td>Suman Dutta  </td><td>M.Com., B.Ed. </td></tr>
                  <tr> <td>57</td><td>Suman Mondal </td><td>MCA</td></tr>
                  <tr> <td>58</td><td>Suman Mukherjee</td><td>M.A. , B.Ed. </td></tr>
                  <tr> <td>59</td><td>Susmita Makhal   </td><td> B.A.,T.T.C, B.Lib.</td></tr>
                  <tr> <td>60</td><td>Sweta Das</td><td>M.Sc, PGDCA</td></tr>
                  <tr> <td>61</td><td>Tanumoy Bera</td><td>M.Sc.,B.Ed.</td></tr>
                    
                  </tbody>
                </table>
              </div>
				
							
						</div>
					</div>
				
			</div>
		</section>
		<!-- End Welcame Area -->