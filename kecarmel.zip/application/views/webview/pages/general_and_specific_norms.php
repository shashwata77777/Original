	<style type="text/css">
		
	</style>
	  <!-- Start Bradcaump area -->
        <div class="ht__bradcaump__area">
            <div class="ht__bradcaump__container">
            	<img src="<?php echo base_url();?>assets/images/bg-png/6.png" alt="bradcaump images">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="bradcaump__inner text-center">
                                <h2 class="bradcaump-title">&nbsp;</h2>
                                <nav class="bradcaump-inner">
                                  <a class="breadcrumb-item" href="<?php echo base_url();?>home">Home</a>
                                  <span class="brd-separetor"><img src="<?php echo base_url();?>/assets/images/icons/brad.png" alt="separator images"></span>
                                  <span class="breadcrumb-item active">&nbsp;</span>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Bradcaump area -->

	<!-- Start Welcame Area -->
		<section class="junior__welcome__area welcome--2 bg-image--9 section-padding--lg">
			<div class="container">
				<div class="row">
					<div class="col-lg-12 col-sm-12 col-md-12">
						<div class="section__title text-center">
							<h2 class="title__line">General and <span class="title-color1">Specific</span> <span class="title-color2">Norms</span></h2>
							
						</div>
					</div>
				</div>
				
<style type="text/css">
	.su-list ul {
  list-style-type: none;
  padding-left: 20px;
}

.su-list li {
  position: relative;
  padding-left: 20px;
  margin-bottom: 10px
}

.su-list li:before {
  position: absolute;
  top: 0;
  left: 0;
  font-family: FontAwesome;
  content: "\f0a1";
  color: #7ec00b;
}
</style>					
					<div class="col-md-12 col-lg-12 col-sm-12 md-mt-40 sm-mt-40">
						<div class="welcome__juniro__inner">
							<div class="su-list"><p></p>
<ul>
<li> Students and staff are expected to speak only in English in school buses and on the school campus except in language classes.  Students are expected to greet all the teachers daily when they meet them first.</li>
<li> Students arriving in school before the first bell, have to go to their own classrooms and get involved  with the day’s lessons in silence. They must not loiter outside their classrooms or in the playground. </li>
<li> On the days of Morning Assembly, at the second bell both students and staff shall assemble in the ground in the class/house order .On dispersal the students shall move to their own classrooms in perfect order.</li>
<li> When the teacher enters the classroom all the students must stand up, greet him/her and remain standing until they are asked to sit or the teacher takes his/her seat. They should thank the teacher when the class is over.</li>
<li> Students shall not leave their classrooms during or in-between two periods, but remain in silence and prepare for the next period. When they are taken out to the library, laboratory, computer lab, language lab, smart class or the playgrounds, they have to move in line keeping to the left side of the corridors silently.</li>
<li> Students shall not enter any other classrooms at any time. They are supposed to look after their own articles. They shall not bring to school valuable and curious articles, gold ornaments or electronic gadgets. Possession and use of mobile phone is strictly prohibited on the school campus and in school buses.</li>
<li> The classrooms, corridors and the school premises shall be kept neat and clean. Waste papers or other waste materials must be thrown into the dust bins provided. Students should take care that the display boards, walls, furniture, black boards, shelves, etc. are kept neat and in order.</li>
<li> No one shall distribute any notice or printed matter among the students or staff without the permission of the Principal. Similarly no meeting, picnic, or any kind of organised group activity shall be arranged without the previous permission of the Principal. Students shall not indulge in political activities.</li>
<li> The Computer lab, Science labs and Library must be used with utmost care. If anything is found missing or damaged , students will have to share the expenses in common. Students must not open the CPU or mouse. </li>
<li> No one shall, without the written permission of the Management, use the address of the school or the title of anybody, if that includes the name of the school when communicating with any person or organisation outside the school.  </li>
<li> No one shall without the written permission of the Management, use the address of the school, or its title if that includes the name of the school when sending any letter or other communication to the press or when distributing any documents outside the school for any purpose other than what is in the interest of the management.  </li>
<li> No one shall without the written permission of the Management, use the address of the school, or its title if that includes the name of the school when sending any letter or other communication to the press or when distributing any documents outside the school for any purpose other than what is in the interest of the management.  </li>
<li>School discourages private tuition by Staff outside the school.  However, the school may organize tuitions for remedial measures and may request parents to pay for it.  </li>
</ul>
<p></p></div>
							
						</div>
					</div>
				
			</div>
		</section>
		<!-- End Welcame Area -->