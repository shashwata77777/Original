	<style type="text/css">
		
	</style>
	  <!-- Start Bradcaump area -->
        <div class="ht__bradcaump__area">
            <div class="ht__bradcaump__container">
            	<img src="<?php echo base_url();?>assets/images/bg-png/6.png" alt="bradcaump images">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="bradcaump__inner text-center">
                                <h2 class="bradcaump-title">Curriculum</h2>
                                <nav class="bradcaump-inner">
                                  <a class="breadcrumb-item" href="<?php echo base_url();?>home">Home</a>
                                  <span class="brd-separetor"><img src="<?php echo base_url();?>/assets/images/icons/brad.png" alt="separator images"></span>
                                  <span class="breadcrumb-item active">Curriculum</span>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Bradcaump area -->

	<!-- Start Welcame Area -->
		<section class="junior__welcome__area welcome--2 bg-image--9 section-padding--lg">
			<div class="container">
				<div class="row">
					<div class="col-lg-12 col-sm-12 col-md-12">
						<div class="section__title text-center">
							<h2 class="title__line"> <span class="title-color1">Curriculum</span> </h2>
              <p>
                The school is affiliated to the ICSE & ISCSYLABUS. The well devised curriculum aims to build up a reputation for academic excellence and successfully guide the students to broaden their horizons and venture out in the competitive world of today with confidence. The curriculum seeks to develop a healthy mind together with a healthy body which is sought to be achieved by the varied and versatile co-curricular activities of the school.
              </p>
							
						</div>
					</div>
				</div>
<br>
          <div class="row">
          <div class="col-lg-12 col-sm-12 col-md-12">
            <div class="section__title text-center">
              <h2 class="title__line"> <span class="title-color2">Teaching Methodology</span> </h2>
              <p>
                An innovative, child- friendly method of teaching is followed with special attention on individual potential. Apart from leading the students successfully on the path of academic excellence, the main aim is to facilitate
and guide the students to become globally competent for their future carrier by providing them amble opportunity to blossom and realize their potentials. 

              </p>
              
            </div>
          </div>
        </div>
        
				
				
					<div class="col-md-12 col-lg-12 col-sm-12 md-mt-40 sm-mt-40">
						<div class="welcome__juniro__inner">
						
							
						</div>
					</div>
				
			</div>
		</section>
		<!-- End Welcame Area -->